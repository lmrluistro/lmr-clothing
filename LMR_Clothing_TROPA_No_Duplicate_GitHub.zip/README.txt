LMR CLOTHING — DUPLICATE ORIGINAL DROP REMOVED

The duplicated “Original drop / Shop the Collection” section has been removed.
The dedicated “TROPA NEW COLLECTION” section remains, including the V1, V2, and V3 designs.
The Shop navigation and Shop Now button now lead directly to the new collection.
The existing brand song player and all assets are retained.

To publish:
1. Replace index.html in your GitHub repository with this version.
2. Upload/replace all files in assets/ (including lmr-brand-song.mp3 and the WebP product images).
3. Commit changes and wait for GitHub Pages to redeploy.
