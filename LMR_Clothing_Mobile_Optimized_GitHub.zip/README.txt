LMR CLOTHING — MOBILE/PERFORMANCE OPTIMIZED WEBSITE

GitHub update:
1. Replace your repository's index.html with this index.html.
2. Open the repository's assets folder and upload the files in this package's assets folder.
3. Keep index.html and assets/ at the repository root level.
4. Commit changes and wait for GitHub Pages to redeploy.

This build uses your latest cropped two-model banner and compresses the banner, product mockups, and logo into WebP files. The banner is preloaded and product images load lazily.

The website still uses static GitHub Pages. Admin edits saved in local browser storage do not sync to all visitors. GCash payment verification is manual.
